package main;

import main.server.TicTacToeServer;

public class TicTacToeInitialisieren {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new TicTacToeServer(8654);
	}

}
