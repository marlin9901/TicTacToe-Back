package main.game;

public enum Zeichen {
	LEER, KREUZ, KREIS;
	
	public int toInt() {
		switch(this) {
		case LEER: return 0;
		case KREUZ: return 1;
		case KREIS: return -1;
		}
		return 0;
	}
}
