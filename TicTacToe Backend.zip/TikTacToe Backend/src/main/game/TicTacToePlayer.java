package main.game;

import main.server.*;

public class TicTacToePlayer {
	TicTacToeClient client;
	TicTacToeGame game;
	Zeichen zeichen;
	boolean isSpieler1;
	boolean isYourTurn;
	
	public TicTacToePlayer(TicTacToeClient client) {
		this.client = client;
		game = null;
		client.setPlayer(this);
		isYourTurn = false; 
	}
	
	public void setEverything(TicTacToeGame game, Zeichen zeichen, boolean isSpieler1) {
		this.game = game;
		this.zeichen = zeichen;
		this.isSpieler1 = isSpieler1;
		
	}

	public Zeichen getZeichen() {
		return zeichen;
	}
	
	public void youWin() {
		client.sendData("WIN");
	}
	
	public void youLose() {
		client.sendData("LOSE");
	}
	
	public void youDraw() {
		client.sendData("DRAW");
	}
	
	public boolean makeMove(int x, int y) {
		return game.makeMove(x, y);
	}
	
	public boolean itsHisTurn() {
		return isYourTurn;
	}

	public void yourTurn() {
		isYourTurn = true;
	}

	public void zugErledigt() {
		isYourTurn = false;
	}
	
	public TicTacToeClient getClient() {
		return client;
	}

	public void kill() {
		
	}
}
