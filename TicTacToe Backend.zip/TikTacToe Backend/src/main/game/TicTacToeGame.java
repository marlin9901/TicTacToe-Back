package main.game;

import java.util.*;
import java.io.*;
import java.net.*;

public class TicTacToeGame extends Thread {
	private TicTacToePlayer[] player = new TicTacToePlayer[2];
	private int id;
	private Zeichen[][] spielfeld;
	TicTacToePlayer winner;
	TicTacToePlayer loser;
	TicTacToePlayer aktivePlayer;
	
	public TicTacToeGame(TicTacToePlayer playerOne, TicTacToePlayer playerTwo, int id){
		this.id = id;
		if(Math.random() < 0.5) {
			player[0] = playerOne;
			player[1] = playerTwo;
		} else {
			player[0] = playerTwo;
			player[1] = playerOne;
		}
		player[0].setEverything(this, Zeichen.KREUZ, true);
		player[1].setEverything(this, Zeichen.KREIS, false);
		aktivePlayer = player[0];
		
		spielfeld = new Zeichen[3][3];
		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 3; j++) {
				spielfeld[i][j] = Zeichen.LEER;
			}
		}
		
		this.id = id;
	}
	
	public void run() {
		
		while(!isGameZuende()) {
			aktivePlayer.yourTurn();
			
			while(aktivePlayer.itsHisTurn()) {
				try {
					sleep(10);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println("Spieler wechsel");
			aktivePlayer = otherPlayer(aktivePlayer);
		}
		if(winner != null) {
			winner.youWin();
			loser.youLose();
		} else {
			player[0].youDraw();
			player[1].youDraw();
		}
	}
	
	private TicTacToePlayer otherPlayer(TicTacToePlayer pl) {
		if(pl == player[0]) {
			return player[1];
		}
		if(pl == player[1]) {
			return player[0];
		}
		return null;
	}
	
	public boolean makeMove(int x, int y) {
		if(!isFrei(x,y)) return false;
		spielfeld[x][y] = aktivePlayer.getZeichen();
		sendUpdate();
		aktivePlayer.zugErledigt();
		
		return true;
	}
	public boolean makeMove(TicTacToePlayer s, int x, int y) {
		if(!isFrei(x,y)) return false;
		spielfeld[x][y] = s.getZeichen();
		sendUpdate();
		s.zugErledigt();
		return true;
	}
	
	private void sendUpdate() {
		String data = "";
		for(int x = 0; x < 3; x++) {
			for(int y = 0; y < 3; y++) {
				data = data + spielfeld[x][y].toInt() + ":";
			}
			data = data.substring(0, data.length()-1);
			data = data + ";";
		}
		data = data.substring(0, data.length()-1);
		
		player[0].getClient().sendData(data);
		player[1].getClient().sendData(data);
	}
	
	private boolean isFrei(int x, int y) {
		return spielfeld[x][y] == Zeichen.LEER;
	}
	
	private void setWinner(Zeichen z) {
		winner = null;
		loser = null;
		if(z == Zeichen.KREUZ) {
			winner = player[0];
			loser = player[1];
		}
		if(z == Zeichen.KREIS) {
			winner = player[1];
			loser = player[0];
		}
	}
	
	private boolean isGameZuende() {
		for(int x = 0; x < 3; x++) {
			boolean reiheVoll = true;
			Zeichen z = spielfeld[x][0];
			if(z == Zeichen.LEER) break;
			for(int y = 1; y < 3; y++) {
				if(spielfeld[x][y] != z) {
					reiheVoll = false;
					break;
				}
			}
			if(reiheVoll) {
				setWinner(z);
				return true;
			}
		}
		for(int y = 0; y < 3; y++) {
			boolean reiheVoll = true;
			Zeichen z = spielfeld[0][y];
			if(z == Zeichen.LEER) break;
			for(int x = 1; x < 3; x++) {
				if(spielfeld[x][y] != z) {
					reiheVoll = false;
					break;
				}
			}
			if(reiheVoll) {
				setWinner(z);
				return true;
			}
		}
		if(spielfeld[1][1] == Zeichen.LEER) return false;
		if(spielfeld[1][1] == spielfeld[0][0] && spielfeld[2][2] == spielfeld[0][0]) {
			setWinner(spielfeld[0][0]);
			return true;
		}
		if(spielfeld[2][0] == spielfeld[1][1] && spielfeld[2][0] == spielfeld[0][2]) {
			setWinner(spielfeld[1][1]);
			return true;
		}
		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 3; j++) {
				if(spielfeld[i][j] == Zeichen.LEER) return false;
			}
		}
		return true;
	}
}
