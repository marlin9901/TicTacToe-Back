package main.server;

import main.*;
import main.game.*;

import java.util.*;
import java.io.*;
import java.net.*;

public class TicTacToeServer {
	private Map<Integer, TicTacToeClient> clients;
	private Map<Integer, TicTacToeGame> games;
	private int clientCount;
	private int gameCount;
	private ServerSocket server;
	private TicTacToeClient lookingForGame;
	
	
	public TicTacToeServer (int port) {
		clients = new HashMap<>();
		clientCount = 0;
		games = new HashMap<>();
		gameCount = 0;
		
		try {
			System.out.println("Server wird gestartet");
			server = new ServerSocket(port);
			System.out.println("Input wird gehandelt");
			handlingInput();
		}catch(IOException e) {
			System.out.println("Something went bad");
			kill();
		}
	}
	
	private void handlingInput() {
		try {
			while(true) {
				Socket socket = server.accept();
				System.out.println("Neuer Spieler");
				clientCount++;
				TicTacToeClient client = new TicTacToeClient(this, socket, clientCount);
				clients.put(clientCount, client);
				client.start();
				startingNewGame(client);
			}
		}catch(Exception e) {
			kill();
			System.out.println("Something went bad");
		}
	}
	
	private void kill() {
		try {
			for(TicTacToeClient i : clients.values()) {
				i.kill();
			}
		}catch(Exception e) {
			System.out.println("Es konnte nicht gekillt werden");
		}
	}
	
	public void removePlayer(int id) {
		System.out.println("Spieler entfernt:" + id);
		clients.remove(id);
	}
	
	private boolean isSomeOneLookingForGame() {
		return lookingForGame != null;
	}
	
	private void startingNewGame(TicTacToeClient client) {
		if(isSomeOneLookingForGame()) {
			gameCount++;
			TicTacToeGame game = new TicTacToeGame(new TicTacToePlayer(client), new TicTacToePlayer(lookingForGame), gameCount);
			games.put(gameCount, game);
			lookingForGame = null;
			game.run();
		}else {
			lookingForGame = client;
		}
	}
}
