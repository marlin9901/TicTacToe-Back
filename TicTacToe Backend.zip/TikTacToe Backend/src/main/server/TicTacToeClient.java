package main.server;

import java.net.Socket;

import java.util.*;

import main.game.*;

import java.io.*;
import java.net.*;

public class TicTacToeClient extends Thread{
	private TicTacToeServer server;
	private int sessID;
	private Socket socket;
	private boolean isPlaying;
	private BufferedReader in;
	private PrintWriter out;
	private TicTacToePlayer player;
	
	

	public TicTacToeClient(TicTacToeServer server, Socket socket, int clientCount) {
		this.server = server;
		this.sessID = clientCount;
		this.socket = socket;
		
		try {
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			out = new PrintWriter(socket.getOutputStream(), true);
		}catch(IOException e) {
			System.out.println("There went something bad");
			kill();
		}
	}
	
	public void setPlayer(TicTacToePlayer player) {
		this.player = player;
	}
	
	public void run() {
		System.out.println("Start handling Input");
		handleIncoming();
	}
	
	private void handleIncoming() {
		
		try {
			String msg;
			while((msg = in.readLine()) != null) interpreteMessage(msg);
		} catch(IOException e) {
			System.out.println("Das Einlesen ist schief gegangen");
			kill();
		}
	}
	
	private void interpreteMessage(String msg) {
		System.out.println(sessID + ": " + msg);
		if(msg.equals("exit")) {
			kill();
			return;
		}
		if(player == null) {
			sendData("GAME_NOT_START");
			return;
		}
		if(!player.itsHisTurn()) {
			sendData("NOT_YOUR_TURN");
			return;
		}
		try {
			String[] pos = msg.split(":");
			if(pos.length != 2) {
				//der move konnte nicht ausgef�hrt werden
				return;
			}
			if(!player.makeMove(Integer.parseInt(pos[0]), Integer.parseInt(pos[1]))) {
				//der move konnte nicht ausgef�hrt werden
			} 
		}catch(NumberFormatException e) {
			//der move konnte nicht ausgef�hrt werden
			return;
		}
	}
	
	public void sendData(String data) {
		out.println(data);
		if(out.checkError()) {
			System.out.println("ERROR \n Nachricht wurde nicht gesendet");
			kill();
		}
	}

	public void kill() {
		server.removePlayer(sessID);
		sendData("KILL");
		if(player != null) {
			player.kill();
		}
	}

}
